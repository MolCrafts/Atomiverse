add_executable(cuda-pw-spin-smear-stress "${CMAKE_CURRENT_LIST_DIR}/main.cpp")
target_link_libraries(cuda-pw-spin-smear-stress PRIVATE atomiverse)
target_compile_features(cuda-pw-spin-smear-stress PRIVATE cxx_std_20)
set_target_properties(cuda-pw-spin-smear-stress PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")
