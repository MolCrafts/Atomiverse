#!/bin/bash -l
#SBATCH --job-name=dft-cpu-mp-detail
#SBATCH --account=naiss2026-1-53-cpu
#SBATCH --partition=cpu
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=00:10:00
#SBATCH --output=.claude/campaigns/dft-gap-wave2-20261026/cpu-pw/detail-%j.log
set -euo pipefail
cd "$SLURM_SUBMIT_DIR"
module load buildenv-gcc/2026.03-mpich
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
pw_blas=/software/sse2/el9_epyc9005/manual/OpenBLAS/0.3.32/g14/hpc1/pthread/lp64/lib
export LD_LIBRARY_PATH="$pw_blas:$LIBRARY_PATH:${LD_LIBRARY_PATH:-}"
pw_out="$PWD/.claude/campaigns/dft-gap-wave2-20261026/cpu-pw"
.claude/scratch/hf-auto/env/bin/python "$pw_out/diagnostic-relink.py" --detailed
set +e
"$pw_out/pw-spin-stress-trace-detailed" --mode mp-strains --mp-width .04 --output "$pw_out/mp-trace-detailed.json" > "$pw_out/mp-trace-detailed.log" 2>&1
