import hashlib,json,re,shlex,subprocess,sys
from pathlib import Path
root=Path.cwd();base=root/'.claude/campaigns/dft-gap-wave2-20261026/cpu-pw';build=base/'build'
trace='--trace' in sys.argv or '--detailed' in sys.argv
detailed='--detailed' in sys.argv
sources=[root/'tools/diagnostics/pw-spin-smear-stress/main.cpp']
if trace:sources.append(base/'pw-solver-trace.cpp')
if detailed:sources.extend([base/'xc-builder-trace.cpp',base/'davidson-trace.cpp'])
args=[]
flagfile=build/('CMakeFiles/atomiverse.dir/flags.make' if trace else 'CMakeFiles/pw-spin-smear-stress.dir/flags.make')
flags=flagfile.read_text()
for key in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']:args+=shlex.split(re.search(r'^'+key+r' = (.*)$',flags,re.M).group(1))
compiler='/software/sse2/el9_epyc9005/manual/GCC/14.3.0/hpc1/bin/c++'
commands=[];objects=[]
for i,p in enumerate(sources):
 obj=base/f'diagnostic-{trace}-{i}.o';objects.append(str(obj))
 cmd=[compiler,*args,'-c',str(p),'-o',str(obj)];commands.append(cmd);subprocess.run(cmd,cwd=build,check=True)
original=shlex.split((build/'CMakeFiles/pw-spin-smear-stress.dir/link.txt').read_text())
link=[original[0],*objects];i=1
while i<len(original):
 if original[i]=='-o':i+=2;continue
 if not original[i].endswith('.o'):link.append(original[i])
 i+=1
exe=base/('pw-spin-stress-trace-detailed' if detailed else 'pw-spin-stress-trace' if trace else 'build/bin/pw-spin-smear-stress')
link+=['-o',str(exe)];commands.append(link);subprocess.run(link,cwd=build,check=True)
receipt={'sources_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},'commands':commands,'library_sha256':hashlib.sha256((build/'libatomiverse.a').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'trace':trace}
(base/('detailed-trace-build.json' if detailed else 'trace-build.json' if trace else 'diagnostic-final-build.json')).write_text(json.dumps(receipt,indent=2)+'\n')
