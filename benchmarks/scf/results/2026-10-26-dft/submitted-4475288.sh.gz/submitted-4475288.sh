#!/bin/bash -l
#SBATCH --job-name=dft-public-acceptance
#SBATCH --account=naiss2026-1-53-cpu
#SBATCH --partition=cpu
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G
#SBATCH --time=00:30:00
#SBATCH --output=.claude/campaigns/dft-gap-20261026/public/validate-%j.log
set -euo pipefail
cd /nobackup/proj/disk/teoroo/personal/jicli594/work/molcrafts/Atomiverse
module load buildenv-gcc/2026.03-mpich
export RUSTUP_TOOLCHAIN=1.99.1-x86_64-unknown-linux-gnu
DFT_BLAS=/software/sse2/el9_epyc9005/manual/OpenBLAS/0.3.32/g14/hpc1/pthread/lp64/lib
export LD_LIBRARY_PATH="$DFT_BLAS:$LIBRARY_PATH:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_WAIT_POLICY=PASSIVE
export PYTHONPATH="$PWD/python/src:$PWD/build-dft-gap-python:$PWD"
DFT_OUT="$PWD/.claude/campaigns/dft-gap-20261026/public"
# Refresh after concurrent CPU repairs, before fingerprinting/measurement.
cmake --build build-dft-gap-python -j8 --target _atomiverse > "$DFT_OUT/final-compile.log" 2>&1
.claude/scratch/hf-auto/env/bin/python -m pytest -q \
  python/tests/test_ks_grid.py tests/benchmarks/test_dft_benchmarks.py \
  tests/benchmarks/test_scientific_benchmarks.py > "$DFT_OUT/contract-tests.log" 2>&1
.claude/scratch/hf-auto/env/bin/python -m benchmarks run --method rks --method uks \
  --tier acceptance --threads 1 --repeats 1 --warmup 0 --timeout 120 \
  --no-snapshot --out "$DFT_OUT/acceptance" > "$DFT_OUT/acceptance.log" 2>&1
