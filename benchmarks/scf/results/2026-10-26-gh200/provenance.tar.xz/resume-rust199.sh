#!/bin/bash -l
set -euo pipefail
TASK_ROOT=/nobackup/proj/disk/teoroo/personal/jicli594/work/atv-hf-python-20261026.p1nSht
exec > >(tee -a "$TASK_ROOT/logs/resume-rust199.log") 2>&1
trap 'rc=$?; date -u +%FT%TZ > "$TASK_ROOT/finished.utc"; printf "%s\n" "$rc" > "$TASK_ROOT/exit-status"' EXIT
module load GPU/buildenv-gcccuda/2026.03-cu13.0
module load GPU/Miniforge/26.3.2-2-eb
export PATH=$(printf '%s' "$PATH" | tr ':' '\n' | awk '!/\/\.x86\// {printf "%s%s",sep,$0;sep=":"}')
export RUSTUP_HOME="$TASK_ROOT/private-rustup"
export RUSTUP_TOOLCHAIN=1.99.1-aarch64-unknown-linux-gnu
export LD_LIBRARY_PATH="${LIBRARY_PATH:-}:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 MKL_NUM_THREADS=8
unset OMP_PROC_BIND OMP_PLACES
source "$TASK_ROOT/env313/bin/activate"
BLAS_PREFIX=/software/sse2/el9_gh200/manual/OpenBLAS/0.3.32/g14/hpc1/pthread/lp64
export LD_LIBRARY_PATH="$BLAS_PREFIX/lib:$LD_LIBRARY_PATH"
rustc -Vv | tee "$TASK_ROOT/logs/rust199-compiler.log"
cmake -S "$TASK_ROOT/source" -B "$TASK_ROOT/build" -U "Rust_*" -DRust_TOOLCHAIN="$RUSTUP_TOOLCHAIN" -DCORROSION_TOOLS_RUST_TOOLCHAIN="$RUSTUP_TOOLCHAIN" 2>&1 | tee "$TASK_ROOT/logs/configure-rust199.log"
cmake --build "$TASK_ROOT/build" --target _atomiverse --parallel 8 2>&1 | tee "$TASK_ROOT/logs/build-rust199.log"
cp "$TASK_ROOT/build/CMakeCache.txt" "$TASK_ROOT/logs/CMakeCache.txt"
cp "$TASK_ROOT/build/compile_commands.json" "$TASK_ROOT/logs/compile_commands.json"
find "$TASK_ROOT/build" -maxdepth 2 -name '*atomiverse*.so' -exec sha256sum '{}' \; > "$TASK_ROOT/logs/binary-sha256.txt"
export PYTHONPATH="$TASK_ROOT/source/python/src:$TASK_ROOT/build"
python - <<'PYMETA' > "$TASK_ROOT/logs/backend-info.json"
import json, sys
from atomiverse import scf
print(json.dumps({'python':sys.version,'cpu':scf.backend_info(),'cuda':scf.cuda_backend_info()}, indent=2))
PYMETA
python -m pytest -q "$TASK_ROOT/source/python/tests/test_hf_bindings.py" --junitxml="$TASK_ROOT/logs/hf-bindings.xml" 2>&1 | tee "$TASK_ROOT/logs/hf-bindings.log"
python -m pytest -q "$TASK_ROOT/source/python/tests/test_scf.py" --junitxml="$TASK_ROOT/logs/scf.xml" 2>&1 | tee "$TASK_ROOT/logs/scf.log"
date -u +%FT%TZ > "$TASK_ROOT/bindings-passed.utc"
# Parent owns framework freezing. Atomic ready publication follows a complete overlay.
for attempt in $(seq 1 36); do
  if test -f "$TASK_ROOT/framework.ready"; then
    test -f "$TASK_ROOT/benchmark.sh"
    bash "$TASK_ROOT/benchmark.sh" 2>&1 | tee "$TASK_ROOT/logs/benchmark.log"
    exit 0
  fi
  sleep 5
done
printf 'Framework was not published within180seconds after binding tests. Build and bindings evidence remains valid.\n' > "$TASK_ROOT/logs/framework-not-ready.txt"
exit 42
