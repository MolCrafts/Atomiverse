#!/bin/bash -l
set -euo pipefail
TASK_ROOT=/nobackup/proj/disk/teoroo/personal/jicli594/work/atv-hf-python-20261026.p1nSht
mkdir -p "$TASK_ROOT/logs"
exec > >(tee -a "$TASK_ROOT/logs/run.log") 2>&1
trap 'rc=$?; date -u +%FT%TZ > "$TASK_ROOT/finished.utc"; printf "%s\n" "$rc" > "$TASK_ROOT/exit-status"' EXIT
module load GPU/buildenv-gcccuda/2026.03-cu13.0
module load GPU/Miniforge/26.3.2-2-eb
export PATH=$(printf '%s' "$PATH" | tr ':' '\n' | awk '!/\/\.x86\// {printf "%s%s",sep,$0;sep=":"}')
export RUSTUP_TOOLCHAIN=stable-aarch64-unknown-linux-gnu
export LD_LIBRARY_PATH="${LIBRARY_PATH:-}:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 MKL_NUM_THREADS=8
unset OMP_PROC_BIND OMP_PLACES
module list 2>&1 | tee "$TASK_ROOT/logs/modules.log"
uname -a
conda create -y -p "$TASK_ROOT/python313" python=3.13 pip
TASK_PYTHON="$TASK_ROOT/python313/bin/python"
"$TASK_PYTHON" --version
command -v gcc g++ nvcc cargo cmake
nvcc --version
cargo --version
"$TASK_PYTHON" -m venv "$TASK_ROOT/env313"
source "$TASK_ROOT/env313/bin/activate"
python -m pip install --upgrade pip
python -m pip install 'molcrafts-molpy==0.20.0' 'pyscf==2.14.0' 'threadpoolctl==3.7.0' 'nanobind==3.1.0' 'pytest==9.1.1' 'scikit-build-core==1.1.1' 'maturin==1.15.0' 'typer>=0.12' ninja 2>&1 | tee "$TASK_ROOT/logs/python-install.log"
python -m pip freeze > "$TASK_ROOT/logs/pip-freeze-base.txt"
# The optional native GPU oracle may be absent on aarch64; preserve resolver evidence.
if python -m pip install --dry-run --only-binary=:all: --report "$TASK_ROOT/logs/gpu4pyscf-resolve.json" 'gpu4pyscf-cuda13x' 'cutensor-cu13' 2>&1 | tee "$TASK_ROOT/logs/gpu4pyscf-dryrun.log"; then
  if python -m pip install --only-binary=:all: 'gpu4pyscf-cuda13x' 'cutensor-cu13' 2>&1 | tee "$TASK_ROOT/logs/gpu4pyscf-install.log"; then
    printf 'installed\n' > "$TASK_ROOT/logs/gpu4pyscf-status.txt"
  else
    printf 'optional-install-failed\n' > "$TASK_ROOT/logs/gpu4pyscf-status.txt"
  fi
else
  printf 'optional-no-compatible-wheel\n' > "$TASK_ROOT/logs/gpu4pyscf-status.txt"
fi
python -m pip freeze > "$TASK_ROOT/logs/pip-freeze-final.txt"
python - <<'PYCHECK'
from importlib.metadata import version
assert version('molcrafts-molpy') == '0.20.0'
import molpy, numpy, pyscf
print('Python scientific runtime', version('molcrafts-molpy'), numpy.__version__, pyscf.__version__)
PYCHECK
BLAS_PREFIX=/software/sse2/el9_gh200/manual/OpenBLAS/0.3.32/g14/hpc1/pthread/lp64
export LD_LIBRARY_PATH="$BLAS_PREFIX/lib:$LD_LIBRARY_PATH"
cmake -S "$TASK_ROOT/source" -B "$TASK_ROOT/build" -G Ninja \
 -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON \
 -DATV_MOLPY_PATH="$TASK_ROOT/molpy-src" -DPython_EXECUTABLE="$TASK_ROOT/env313/bin/python" \
 -DATV_BUILD_HF=ON -DATV_BUILD_CUDA=ON -DATV_BUILD_PYTHON=ON -DATV_BUILD_EVALUATE=ON \
 -DATV_BUILD_PW=OFF -DATV_BUILD_GPW=OFF -DATV_BUILD_KSPACE=OFF -DATV_BUILD_XC_ORACLE=OFF \
 -DATV_BUILD_MD=OFF -DATV_BUILD_MC=OFF -DATV_BUILD_MINIMIZER=OFF -DATV_BUILD_VIB=OFF \
 -DATV_BUILD_PATH=OFF -DATV_BUILD_SEMIEMPIRICAL=OFF -DATV_BUILD_POTENTIALS=OFF \
 -DATV_BUILD_NEIGHBOR=OFF -DATV_BUILD_ANALYSIS=OFF -DATV_BUILD_IO=OFF \
 -DATV_BUILD_TESTS=OFF -DATV_BUILD_BENCHMARKS=OFF -DATV_BUILD_EXAMPLES=OFF \
 -DATV_BUILD_LAUNCHER=OFF -DATV_BUILD_KOKKOS=OFF -DATV_USE_MPI=OFF \
 -DATV_CUDA_PREC_MODE=double -DATV_REAL_STORAGE=double -DATV_REAL_WORK=double \
 -DCMAKE_CUDA_ARCHITECTURES=90 -DBLAS_LIBRARIES="$BLAS_PREFIX/lib/libopenblas.so" \
 -DLAPACK_LIBRARIES="$BLAS_PREFIX/lib/libopenblas.so" 2>&1 | tee "$TASK_ROOT/logs/configure.log"
cmake --build "$TASK_ROOT/build" --target _atomiverse --parallel 8 2>&1 | tee "$TASK_ROOT/logs/build.log"
cp "$TASK_ROOT/build/CMakeCache.txt" "$TASK_ROOT/logs/CMakeCache.txt"
cp "$TASK_ROOT/build/compile_commands.json" "$TASK_ROOT/logs/compile_commands.json"
find "$TASK_ROOT/build" -maxdepth 2 -name '*atomiverse*.so' -exec sha256sum '{}' \; > "$TASK_ROOT/logs/binary-sha256.txt"
export PYTHONPATH="$TASK_ROOT/source/python/src:$TASK_ROOT/build"
python - <<'PYMETA' > "$TASK_ROOT/logs/backend-info.json"
import json, sys
from atomiverse import scf
print(json.dumps({'python':sys.version,'cpu':scf.backend_info(),'cuda':scf.cuda_backend_info()}, indent=2))
PYMETA
python -m pytest -q "$TASK_ROOT/source/python/tests/test_hf_bindings.py" --junitxml="$TASK_ROOT/logs/hf-bindings.xml" 2>&1 | tee "$TASK_ROOT/logs/hf-bindings.log"
python -m pytest -q "$TASK_ROOT/source/python/tests/test_scf.py" --junitxml="$TASK_ROOT/logs/scf.xml" 2>&1 | tee "$TASK_ROOT/logs/scf.log"
date -u +%FT%TZ > "$TASK_ROOT/bindings-passed.utc"
# Parent owns framework freezing. Atomic ready publication follows a complete overlay.
for attempt in $(seq 1 36); do
  if test -f "$TASK_ROOT/framework.ready"; then
    test -f "$TASK_ROOT/benchmark.sh"
    bash "$TASK_ROOT/benchmark.sh" 2>&1 | tee "$TASK_ROOT/logs/benchmark.log"
    exit 0
  fi
  sleep 5
done
printf 'Framework was not published within180seconds after binding tests. Build and bindings evidence remains valid.\n' > "$TASK_ROOT/logs/framework-not-ready.txt"
exit 42
