#!/bin/bash
set -euo pipefail
TASK_ROOT=/nobackup/proj/disk/teoroo/personal/jicli594/work/atv-hf-python-20261026.p1nSht
source "$TASK_ROOT/env313/bin/activate"
export PYTHONPATH="$TASK_ROOT/source/python/src:$TASK_ROOT/build"
cd "$TASK_ROOT/source"
python -m pip install 'pydantic==2.14.1' "$TASK_ROOT/ci-source" 2>&1 | tee "$TASK_ROOT/logs/framework-install.log"
python -m pip install --no-build-isolation --no-deps -e "$TASK_ROOT/source/python" 2>&1 | tee "$TASK_ROOT/logs/atv-pure-python-install.log"
python -m pip freeze > "$TASK_ROOT/logs/pip-freeze-measurement.txt"
python -m benchmarks catalog > "$TASK_ROOT/logs/final-catalog.json"
python - <<'CHECK'
from pathlib import Path
from benchmarks.framework.provenance import source_info
import os,json
root=Path.cwd()
print(json.dumps({'source_tree_sha256': source_info(root, root/'source-manifest.json')['tree_sha256']}))
CHECK
mkdir -p "$TASK_ROOT/results"
aggregate=0
run_campaign() {
  campaign="$1"; shift
  set +e
  python -m benchmarks run "$@" --timeout 600 --require-cuda \
    --source-manifest "$TASK_ROOT/source/source-manifest.json" --out "$TASK_ROOT/results/$campaign" \
    2>&1 | tee "$TASK_ROOT/logs/$campaign.log"
  status=${PIPESTATUS[0]}
  set -e
  printf '%s\n' "$status" > "$TASK_ROOT/logs/$campaign.exit-status"
  if test "$status" -ne 0; then aggregate=1; fi
  if test -f "$TASK_ROOT/results/$campaign/results.json"; then
    python -m benchmarks validate --input "$TASK_ROOT/results/$campaign/results.json" \
      > "$TASK_ROOT/logs/$campaign.schema.log" || aggregate=1
  else
    aggregate=1
  fi
  if test -f "$TASK_ROOT/results/$campaign/snapshots/benchmark.json"; then
    molci validate-snapshot "$TASK_ROOT/results/$campaign/snapshots/benchmark.json" \
      > "$TASK_ROOT/logs/$campaign.molci.json" || aggregate=1
  else
    aggregate=1
  fi
}
run_campaign acceptance-cpu8-gpu1 --tier acceptance --threads 8 --repeats 1 --warmup 0
run_campaign water16-performance-cpu1-gpu1 --tier performance --method rhf --system water_chain16 --threads 1 --repeats 5 --warmup 1
run_campaign water16-performance-cpu8-gpu1 --tier performance --method rhf --system water_chain16 --threads 8 --repeats 5 --warmup 1
python - <<'SUMMARY' > "$TASK_ROOT/logs/required-cell-review.json"
from pathlib import Path
import json
root=Path.cwd().parent/'results'; result={}
for path in sorted(root.glob('*/results.json')):
 b=json.loads(path.read_text())
 result[path.parent.name]={'campaign_id':b['campaign_id'],'profile':b['profile'],'summary':b['summary'],
   'required_nonpass':[{'row':c['row_id'],'system':c['system_id'],'participant':c['participant_id'],'status':c['status'],'numerical':c['numerical'],'reason':c.get('reason'),'checks':c['checks']} for c in b['cells'] if c['required'] and (c['status']!='completed' or c['numerical']!='pass')],
   'all_cells':[{'row':c['row_id'],'system':c['system_id'],'participant':c['participant_id'],'required':c['required'],'status':c['status'],'numerical':c['numerical'],'reason':c.get('reason'),'timing':c['timing'],'speedup':c.get('speedup'),'speedup_reason':c.get('speedup_reason')} for c in b['cells']]}
print(json.dumps(result,indent=2))
SUMMARY
exit "$aggregate"
