#!/bin/bash
set -euo pipefail
TASK_ROOT=/nobackup/proj/disk/teoroo/personal/jicli594/work/atv-hf-python-20261026.p1nSht
cd "$TASK_ROOT"
for attempt in $(seq 1 720); do
 if test -f bindings-passed.utc; then break; fi
 sleep 5
done
test -f bindings-passed.utc
printf '4e72db4f39ee5c44843703497290b2cd5962a17a1d0e7d2d7a1ce8edd0397eeb  benchmark-source-gpu.tar.gz\n' | sha256sum --check
cp build-source-manifest-patched.json build-source-manifest.json
tar -xzf benchmark-source-gpu.tar.gz -C source
python3 - <<'VERIFY'
from pathlib import Path
import hashlib,json
root=Path('source').resolve(); m=json.loads((root/'source-manifest.json').read_text())
for name, expected in m['source_files'].items():
 p=(root/name).resolve()
 assert root in p.parents and p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected,name
actual=hashlib.sha256(json.dumps(m['source_files'],sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
assert actual==m['tree_sha256']=='cfd36d03d4a3e6e3190d2dabead270a7bee82ef1489d1fd5adbc14941a32c559'
print('Frozen source tree verified',actual)
VERIFY
printf 'frozen source verified; benchmark preflight validates native CLI before science\n' > framework.ready.tmp
mv framework.ready.tmp framework.ready
